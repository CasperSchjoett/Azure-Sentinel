
SAFE = 'safe'
SPAM = 'spam'
SUSPICIOUS = 'suspicious'
SCAM = 'scam'
PHISHING = 'phishing'
MALWARE = 'malware'
MALICIOUS = 'malicious'
TARGETED = 'targeted'
